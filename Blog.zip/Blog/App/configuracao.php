<php
define('APP', dirname(__FILE__));
define('URL', 'http://localhost/Blog');
define('APP_NOME','auladePHPOrientadaaObjetoscomMVC');
const APP_VERSAO = '1.0.0';


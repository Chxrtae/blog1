<h1><?php echo $dados['titulo'];    ?></h1>
<p> <?php echo $dados['descricao']; ?></p>
<h3><?= APP_VERSAO ?></h3>
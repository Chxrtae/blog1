<footer class="bg-dark p-5 text-light">
   <div class="container  text-center">
    <small> Aula de PHP Orientado a Objetos e MVC. Versão <?= APP_VERSAO ?>
         <div class="border-top mt-3">
         &COPY; 2024 - <?= date('Y') ?> Programação Web
      </div>
    </small>
  </div>
</footer>

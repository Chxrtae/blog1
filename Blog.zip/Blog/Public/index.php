<?php
include "./../App/Libraries/Rota.php";
include"../App/Libraries/Controller.php";
include "./../App/Configuracao.php";
include "./../App/Libraries/Database.php";

$db = new Database;
/*




date_default_timezone_set('America/Cuiaba');
$id = 2;
$usuarioId = 12;
$titulo = 'titulo editado';
$txto = 'texto editado';
$criadoEm = date('y-m-d h:i:s');

$db->query("UPDATE posts SET usuario_id= :usuario_id, titulo= :titulo, texto=:texto, criadoEm=:criadoEm where id=:id");

$db->bind(':id',$id);
$db->bind(':usuario_id',$usuarioid);
$db->bind(':titulo',$titulo);
$db->bind(':texto',$texto);
$db->bind(':criadoEm',$criadoEm);

$db->executa();
echo '<hr>Total resultados:'.$db->totalResultados();

/*
$usuarioId = 10;
$titulo = " A volta de quem não foi";
$texto = "Avolta de quem não foi é uma obra literária brasileira que ganhou o prêmio de melhor...";

$db->query("INSERT INTO posts (usuario_id. titulo, texto) VALUES(:usuario_id, :titulo, :texto)");

$db->bind(":usuario_id", $usuarioId);
$db->bind(":titulo", $titulo);
$db->bind("texto",$texto);

$db->executa();

echo '<hr>TotalResultados'.$db->totalResultados();
echo '<hr>Último ID: '.$db->ultimoIdInserido();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?=APP_NOME?></title>
    <link rel="stylesheet" type="text/css" href="<?=URL?>/public/css/estilo.css"/>
    <link rel ="stylesheet" type="text/css" href="<?URL?>/public/bootstrap/css/bootstrap.css"/>
</head>
<body>

    <?php
    include "../App/Views/header.php";
    $rotas = new Rota();
    include "../App/Views/footer.php";
    ?>
    <script src="<?=URL?>/public/js/query.js"></script>
    <script src="<?=URL?>/publi/bootstrap/bootstrap.js"></script>
</body>
</html>